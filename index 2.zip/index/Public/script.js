document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('madLibForm').addEventListener('submit', function (event) {
        event.preventDefault();

        // Get form values
        var verb = document.getElementById('verb').value;
        var noun1 = document.getElementById('noun1').value;
        var adjective1 = document.getElementById('adjective1').value;
        var noun2 = document.getElementById('noun2').value;
        var verb2 = document.getElementById('verb2').value;
        var adjective2 = document.getElementById('adjective2').value;
        var noun3 = document.getElementById('noun3').value;
        

        // Generate story
        var story = "One day, I was " + verb + " along the " + noun1 + " when I stumbled upon a " + adjective1 + " " + noun2 + ". It was " + adjective2 + ", and I couldn't resist " + verb2 + " closer to get a better look. As I approached, I noticed a " + noun3 + " lying next to it, glinting in the sunlight. To my surprise, the " + noun3 + " opened to reveal a hidden " + noun2 + " inside. I couldn't believe my luck! It was a truly " + adjective1 + " discovery that I would never forget.";

        // Display story
        alert(story);
    });
});
